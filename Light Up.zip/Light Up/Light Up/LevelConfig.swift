//
//  LevelConfig.swift
//  Light 'Em Up!
//
//  Created by Jack Mann on 12/7/23.
//

import Foundation

func levels(num: Int) -> [[Tile]] { // Contains all the level layouts -- didn't have time to try advanced levels
    // Levels aren't ordered by difficulty -- sort of an ad hoc ordering (with a secret message!)
    var levels = Array(repeating: Array(repeating: Array(repeating: Tile(), count:5), count:5), count:26)
    
    levels[1] = [
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()]
    ]
    
    levels[2] = [
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)]
    ]
    
    levels[3] = [
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[4] = [
        [Tile(),Tile(),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()]
    ]
    
    levels[5] = [
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)]
    ]
    
    levels[6] = [
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()]
    ]
    
    levels[7] = [
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()]
    ]
    
    levels[8] = [
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()]
    ]
    
    levels[9] = [
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()]
    ]
    
    levels[10] = [
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)]
    ]
    
    levels[11] = [
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[12] = [
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()]
    ]
    
    levels[13] = [
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()]
    ]
    
    levels[14] = [
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)]
    ]
    
    levels[15] = [
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()]
    ]
    
    levels[16] = [
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(),Tile()]
    ]
    
    levels[17] = [
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[18] = [
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()]
    ]
    
    levels[19] = [
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[20] = [
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[21] = [
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(),Tile(isOn: true)]
    ]
    
    levels[22] = [
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(isOn: true),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[23] = [
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)]
    ]
    
    levels[24] = [
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(),Tile(),Tile(),Tile()],
        [Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(isOn: true),Tile(isOn: true),Tile()]
    ]
    
    levels[25] = [
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(isOn: true),Tile(),Tile(isOn: true),Tile(),Tile(isOn: true)],
        [Tile(isOn: true),Tile(),Tile(),Tile(),Tile(isOn: true)],
        [Tile(),Tile(isOn: true),Tile(),Tile(isOn: true),Tile()],
        [Tile(),Tile(),Tile(isOn: true),Tile(),Tile()]
    ]
    
    return levels[num]
}
