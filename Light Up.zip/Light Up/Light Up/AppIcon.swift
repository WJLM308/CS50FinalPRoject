//
//  AppIcon.swift
//  Light Up
//
//  Created by Jack Mann on 12/6/23.
//

import SwiftUI

struct AppIcon: View { // This generates the app icon
    var isOn = false
    var body: some View {
        RoundedRectangle(cornerRadius: 24).frame(width: 120, height: 120).foregroundColor(Color("default_on")).border(Color.black, width: 12).cornerRadius(12).overlay(Text("CS50")).font( .largeTitle).foregroundColor(Color.black)
    }
}


struct AppIcon_Previews: PreviewProvider {
    static var previews: some View {
        AppIcon()
    }
}
