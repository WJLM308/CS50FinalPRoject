//
//  Tile.swift
//  Light Up
//
//  Created by Jack Mann on 12/3/23.
//

import SwiftUI

struct Tile: View { // This builds a tile
    var isOn: Bool = false // On/Off state
    var body: some View {
        RoundedRectangle(cornerRadius: 12).frame(width: 60, height: 60).foregroundColor(isOn ? Color("default_on"): Color("default_off")).border(Color.black, width: 6).cornerRadius(6)
    }
}

struct Tile_Previews: PreviewProvider {
    static var previews: some View {
        Tile()
    }
}
