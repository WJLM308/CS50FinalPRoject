# Light 'Em Up!: A game by Jack Mann
https://www.youtube.com/watch?v=0vm9eLEoxUU

This project was written in Xcode 12.4 and Swift 5. The latter is probably required to run it, and the former (being somewhat outdated -- my mac is from 2013 and can't get any newer version) has a chance of not being compatible with newer versions, but hopefully it will still run. The game is based on "Lights Out", so I'd recommend looking that up to get a sense of what this is about.

The header file/container, "Light 'Em Up!.xcodeproj" is the project file, and it contains a lot of metadata. It is the parent of the other folders.

All files in the "Light Up" and "Products" folders are used; "Light UpTests" and "Light UpUITests" are unused.

"Products" has the app file, which I'm not completely sure how to use (it hasn't been needed for development) -- everything works on my end, so don't change it I guess.

"Light Up" has this document and "DESIGN.md", which contain my design comments. "Assets.xcassets" contains a color scheme and the app logo, and Info.plist has some sort of necessary information but I don't really know what it does.

"Light_UpApp.swift" is, as far as I can tell, the central file in the "Light Up" folder. However, this file is unchanged from its default; my code instead centers around "ContentView.swift", which brings all the other views together.

"LevelSelect.swift" is displayed on the main menu screen along with the reset progress button. This allows you to choose a level and play it. Initially, only the first level is unlocked, but the current level unlock can be edited in the "ContentView.swift" -- just make sure to set it back when you're done testing.

"Navigator.swift" appears at the bottom of each level. It allows players to go from one level directly to its adjacent ones, or back to the main menu. This is also affected by the unlocks.

"Level.swift" contains the information for building a level, and upon level completion it locks the board, shows a victory text, and unlocks the next level. It is in this file where the tile clicks are handled -- "Tile.swift" is only used to generate the tile itself and store the on/off appearance.

"AppIcon.swift" is where I generated the image that I used for, well, the App Icon. I'm not publishing this (at least not until a lot more work is done), so I figured that a "CS50"-labeled tile would be appropriate.

Finally, "LevelConfig.swift" -- which is NOT a SwiftUI file, unlike the rest of them -- stores the maps of all 25 levels. Due to unforeseen time constraints, there are no fancy gameplay addons to the original "Lights Out" game, and just different level arrangements. This will be discussed more in DESIGN.md.
