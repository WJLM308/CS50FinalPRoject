# Design choices

Swift, along with the additional XCode functionality, is really complex and confusing. I considered using either the "SpriteKit" or "SwiftUI" model for making this project -- they are completely different. I went with "SwiftUI", because it's more intuitive and easier to test due to the "preview" feature.

It took a long time to learn Swift; a lot longer than I expected. Nearly every error I ran in to was completely foreign to me. Originally I was planning for this game to essentially be a "Lights Out 2", with additional gameplay features such as variable level shapes/sizes and unique tiles with special properties (such as double-radius activiation, portal-like activation, on-only activation, etc.), but this idea had to be scrapped due to time constraints.

The code implementation of these additional features wasn't really the issue -- I could probably spend a day and finish all of it along with debugging. The real problem is that I would need to do a lot of math (mostly lin. alg.) for these custom levels to make sure they were both solvable and mostly nonredundant. Unfortunately, that takes a lot of time, so I went with the normal game, and just made levels with different starting conditions, while checking for their solvability with existing online calculators. Sure, I could have created a calculator for solvability of a game with additional features and tiles, but working that out for a heterogenous gameboard would take a LOT longer.

So, moving on to the project itself. Each of the .swift files except LevelConfig are views, meaning they generate something on screen. This is all put together by ContentView. Due to this hierarchy I had to manage a lot of variables through ContentView, which is why I have so many @Binding (essentially inherited) variables in the child views. Even this wasn't enough to force updates between views, which is why you see several .onAppear or .onChange modifiers that interact with the @Binding variables. I decided against using the built-in button features, because I didn't like the special affects they came with. I just decided to use .OnTapGesture modifiers instead.

Obviously I didn't put everything in ContentView, because that is poor formatting (and it make debugging slow and frustrating). Thus, I split up my work into new files in a mostly ad hoc fashion, but I did at least plan for separate Level and Tile files (in fact, these were my first three files before I had to break it up further).

I initially designed the Tile appearance with the goal of creating different-colored tiles for different types. The default I figured would look nice as a sort of basic yellow light, with the color scheme roughly reflecting the color of a cartoony incandescent lightbulb in on/off states. Then, when I wanted to create a level menu, I decided to reuse the tile theme, and essentially make the menu look like a level (which lights up as you complete levels). This theme continued, so all buttons (with the exception of a confirmation popup) look like that. Of course, with the add-on gameplay tiles scrapped, this is the only color scheme.


The level design was somewhat straightforward -- I just had to make 25 patterns that were solvable (the first being blank, of course). I decided to write my name in it, which saved a lot of creativity. Otherwise it's mostly geometrical shapes, or certain references.

And that's about it! Sorry if I accidentally forgot to mention something important -- there was a lot to talk about.
