//
//  Level.swift
//  Light Up
//
//  Created by Jack Mann on 12/3/23.
//

import SwiftUI
// This builds the level, and handles the tiles
// For some reason this file didn't like some of my comments right after brackets (I think), so I moved them. Looked it up and I think it's a rare bug
struct Level: View {
    @Binding var display: Int // Inherited
    @State var tiles: [[Tile]] // Level grid
    @State var isSolved = false // Self-explanatory
    @Binding var unlocked: Int // Inherited
    
    var body: some View {
        ZStack{
            Text("Level \(display)") // "Level _"
                .padding(.top, 100.0)
                .frame(maxHeight: .infinity, alignment: .top)
                .font(.largeTitle)
                
            VStack(spacing: 1.0) {
                // 25 tiles (5x5 array)
                ForEach(0..<5) { i in
                    HStack(spacing: 1.0) {
                        ForEach(0..<5) { j in
                            // Reset appearance if moving using navigator
                            tiles[i][j].onChange(of: display) { value in
                                isSolved = false // This gets executed 25 times lol, but all the other things I've tried so far don't reset it
                                tiles[i][j] = levels(num: display)[i][j]
                            }.onTapGesture {
                                // When clicked, update puzzle
                                if !isSolved {
                                    light(row: i, col: j)
                                    check_isSolved()
                                }
                            }
                        }
                    }
                }
            }
            
            Text("Well Done!").foregroundColor(isSolved ? Color.black : Color.white).padding(.bottom, 150).frame(maxHeight: .infinity, alignment: .bottom).font(.title) // Pops up upon finish
        }
    }
    
    func light(row: Int, col: Int) {
        // Toggles the tiles in a plus pattern
        for i in -1...1 {
            for j in -1...1 {
                if abs(i) + abs(j) < 2 {
                    guard (-1 < min(row+i,col+j) && max(row+i,col+j) < 5) else {continue} // Prevents edge cases, no pun intended
                    tiles[row+i][col+j].isOn.toggle()
                }
            }
        }
    }
    
    func check_isSolved(){
        // Check if all tiles are on
        for row in tiles {
            for tile in row {
                if !tile.isOn {
                    return // If any tile is off, end loop
                }
            }
        }
        if display + 1 > unlocked {
            // Unlock next level
            unlocked += 1 // This can technically unlock a nonexistent level 26, but that doesn't matter
        }
        isSolved = true // Triggers "Well Done!", and stops the player from toggling the buttons
    }
}

struct Level_Previews: PreviewProvider {
    @State static var display = 0
    @State static var unlocked = 1
    @State static var tiles = levels(num: 1)
    static var previews: some View {
        Level(display: $display, tiles: tiles, unlocked: $unlocked)
    }
}
