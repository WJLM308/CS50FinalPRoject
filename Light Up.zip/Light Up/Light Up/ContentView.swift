//
//  ContentView.swift
//  Light Up
//
//  Created by Jack Mann on 12/3/23.
//

import SwiftUI

struct ContentView: View { // This is where everything comes together
    @State private var display = 0 // Which screen to show -- Menu=0, Levels=1-25
    @AppStorage("unlocked_levels") var unlocked = 1 // Saves progress between instances
    @State private var showingAlert = false // For the reset confirmation popup
    var body: some View {
        if display == 0 {
            ZStack {
                Text("Light 'Em Up!") // Title at top
                    .padding(.top, 50.0)
                    .frame(maxHeight: .infinity, alignment: .top)
                    .font(.largeTitle)
                LevelSelect(display: $display, unlocked: $unlocked) // Level selection menu
                // The bottom button is "off" until you beat the first level, then unlocks option to reset progress
                RoundedRectangle(cornerRadius: 12).frame(width: 304, height: 60).foregroundColor(unlocked > 1 ? Color("default_on"):Color("default_off")).border(Color.black, width: 6).cornerRadius(6).overlay(Text("Reset Progress").font(.title).foregroundColor(Color.black)).frame(maxHeight: .infinity, alignment: .bottom).onTapGesture {
                    if unlocked > 1 { // Call confirmation popup
                        showingAlert = true
                    }
                    }
                }.alert(isPresented: $showingAlert) { // Reset progress confirmation popup
                    Alert(title: Text("Are you sure you want to reset your progress?"), message: Text("This action cannot be undone."), primaryButton: .destructive(Text("Reset")) {
                        unlocked = 1
                    }, secondaryButton: .cancel())
            }
        }
        else {
            ZStack {
                Level(display: $display, tiles: levels(num: display), unlocked: $unlocked) // Displays level
                Navigator(display: $display, unlocked: $unlocked) // Displays navigation buttons below level
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
