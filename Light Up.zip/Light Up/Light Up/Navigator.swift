//
//  Navigator.swift
//  Light Up
//
//  Created by Jack Mann on 12/6/23.
//

import SwiftUI

struct Navigator: View { // This builds the navigator component at the bottom of each level
    @Binding var display: Int // Inherited
    @Binding var unlocked: Int // Inherited
    var body: some View {
        HStack(spacing: 1.0) {
            // Previous level button
            Tile(isOn: display<unlocked+2).overlay(Text(String(display-1)).font(.title).foregroundColor(Color.black)).opacity(display==1 ? 0:1).onTapGesture {
                if display != 1 && display<unlocked+2{
                    display -= 1
                }
            }
            // Main Menu button
            RoundedRectangle(cornerRadius: 12).frame(width: 182, height: 60).foregroundColor( Color("default_on")).border(Color.black, width: 6).cornerRadius(6).overlay(Text("Main Menu").font(.title).foregroundColor(Color.black)).onTapGesture {display = 0}
            // Next level button
            Tile(isOn: display<unlocked).overlay(Text(String(display+1)).font(.title).foregroundColor(Color.black)).opacity(display==25 ? 0:1).onTapGesture {
                if display != 25 && display<unlocked{
                    display += 1
                }
            }
            
        }.frame(maxHeight: .infinity, alignment: .bottom)
    }
}

struct Navigator_Previews: PreviewProvider {
    @State static var display = 1
    @State static var unlocked = 1
    static var previews: some View {
        Navigator(display: $display, unlocked: $unlocked)
    }
}
