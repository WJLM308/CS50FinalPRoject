//
//  LevelSelect.swift
//  Light Up
//
//  Created by Jack Mann on 12/6/23.
//

import SwiftUI

struct LevelSelect: View { // This builds the level selector component
    @State private var levels = Array(repeating: Array(repeating: Tile(), count:5), count:5) // Array of tiles used as level buttons
    @Binding var display: Int // Inherited
    @Binding var unlocked: Int // Inherited
    var body: some View {
        ZStack {
            Text("Choose Level:") // Text at top
                .padding(.top, 180.0)
                .frame(maxHeight: .infinity, alignment: .top)
                .font(.title)
            VStack(spacing: 1.0) { // 25 levels (5x5 grid)
                ForEach(0..<5) { i in
                    HStack(spacing: 1.0) {
                        ForEach(0..<5) { j in
                            levels[i][j].overlay(Text(String(5*i+j+1)).font(.title).foregroundColor(Color.black)).onAppear { // These next two just update the locked/unlocked appearance
                                levels[i][j].isOn = 5*i+j < unlocked
                            }.onChange(of: unlocked) { value in
                                levels[i][j].isOn = 5*i+j < unlocked
                            }.onTapGesture { // Clicking an unlocked level sends you to that screen
                                if levels[i][j].isOn {
                                    display = 5*i+j+1
                                }
                            }
                            
                        }
                    }
                }
            }
        }
    }
}

struct LevelSelect_Previews: PreviewProvider {
    @State static var display = 0
    @State static var unlocked = 1
    static var previews: some View {
        LevelSelect(display: $display, unlocked: $unlocked)
    }
}
