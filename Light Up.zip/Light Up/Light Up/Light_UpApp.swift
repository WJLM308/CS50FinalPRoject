//
//  Light_UpApp.swift
//  Light Up
//
//  Created by Jack Mann on 12/3/23.
//

import SwiftUI

@main
struct Light_UpApp: App { // This is the actual app file, I think. Nothing special here.
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
